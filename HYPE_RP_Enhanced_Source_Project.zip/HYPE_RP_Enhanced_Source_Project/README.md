# HYPE RP — One State-inspired Android 3D RP

This is a rebuildable Android Studio project based on the HTML game bundled in the user's supplied `HYPE-RP-full-3D.apk`. It keeps the existing game content and adds a more robust full-screen, landscape Android WebView shell (local storage, hardware acceleration, immersive mode, and recovery if Android kills the WebView renderer).

## Build from an Android phone with GitHub
1. Download and extract this ZIP.
2. Create a new GitHub repository (for example `hype-rp-android`).
3. Upload the contents of this folder to the repository root (not the ZIP itself).
4. Open the repository's **Actions** tab and select **Build HYPE RP APK**.
5. Tap **Run workflow**. Wait for the workflow to finish successfully.
6. Open the completed run, download the `HYPE-RP-Android-APK` artifact, extract it, and install `app-debug.apk`.

## Current status
- The existing embedded HTML/Three.js-style 3D game content is preserved; this project does not replace it with a screenshot or a static mock-up.
- Android build configuration and WebView wrapper have been updated.
- **This ZIP is source code, not a compiled APK.** A successful GitHub Actions build and a real-device play test are still required.
- The game currently runs as a local single-device game. Internet permission in the Android wrapper does **not** mean multiplayer is implemented. Online multiplayer needs a separately hosted server, networking code, and a database/API; do not advertise it as working until tested.
- The project is a foundation for a One State-inspired HYPE RP experience, not an official One State asset pack or a claim of identical graphics.

## Project structure
- `app/src/main/assets/index.html` — existing game and its bundled data
- `app/src/main/java/com/hype/rp/MainActivity.java` — Android WebView host
- `app/src/main/AndroidManifest.xml` — app permissions and landscape launch configuration
- `.github/workflows/build-apk.yml` — cloud APK build workflow
